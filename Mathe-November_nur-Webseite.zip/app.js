'use strict';

// Lernabenteuer v1 – bewusst ohne externe Bibliotheken oder API-Aufrufe.
// Kinderbezogene Daten bleiben ausschließlich im lokalen Browser.
const STORAGE_KEY = 'lernabenteuer-progress-v1';
const DAILY_TARGET = 20;
const TASKS_PER_MISSION = 5;
const MATH_MISSION_TARGET = 20; // Mathematik ohne Zeitdruck, andere Fächer bleiben bei fünf Aufgaben.
const SUBJECTS = ['math','german','english','flags'];
const MAX_LEVEL = {math:7,german:5,english:4,flags:4};

function todayLocal() {
  const now = new Date();
  const pad = n => String(n).padStart(2, '0');
  return `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}`;
}
function emptyProgress() {
  return { stars: 0, answered: 0, sessions: 0, day: todayLocal(), todayAnswered: 0, lastSubject: 'german', memoryWins: 0, reviewBank: [], skills: Object.fromEntries(SUBJECTS.map(subject=>[subject,newSkill()])) };
}
function loadProgress() {
  const defaults = emptyProgress();
  try {
    const p = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    const safe = {...defaults};
    for (const key of ['stars','answered','sessions','todayAnswered']) {
      if (Number.isSafeInteger(p[key]) && p[key] >= 0) safe[key] = p[key];
    }
    if (p.day === defaults.day) safe.day = p.day;
    else safe.todayAnswered = 0;
    if (SUBJECTS.includes(p.lastSubject)) safe.lastSubject = p.lastSubject;
    if(Number.isSafeInteger(p.memoryWins) && p.memoryWins >= 0) safe.memoryWins = p.memoryWins;
    safe.reviewBank=safeReviewBank(p.reviewBank);
    for(const subject of SUBJECTS) safe.skills[subject]=safeSkill(p.skills?.[subject],subject);
    return safe;
  } catch (_) { return defaults; }
}
let progress = loadProgress();
let session = null;

function saveProgress() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(progress)); } catch (_) { /* private mode: session-only */ }
  renderProgress();
}
function element(id) { return document.getElementById(id); }
function shuffle(items) {
  const arr = [...items];
  for (let i=arr.length-1; i>0; i--) {
    const j = Math.floor(Math.random()*(i+1));
    [arr[i],arr[j]]=[arr[j],arr[i]];
  }
  return arr;
}
function int(min,max) { return min + Math.floor(Math.random()*(max-min+1)); }

function multipleChoice(answer, alternatives) {
  const values = [answer, ...alternatives.filter(x => x !== answer)];
  const unique = [...new Set(values.map(String))];
  if (unique.length < 4) throw new Error('Zu wenige Antwortmöglichkeiten');
  return shuffle(unique.slice(0,4));
}
function numericChoices(answer, step=1) {
  const deltas = shuffle([step,-step,step*2,-step*2,step*3,-step*3,step*4,-step*4,5,-5,10,-10,1,-1]);
  const options = [answer];
  for(const delta of deltas) {
    const candidate = answer+delta;
    if(candidate >= 0 && !options.includes(candidate)) options.push(candidate);
    if(options.length === 4) break;
  }
  return shuffle(options.map(String));
}
function makeMathTasks() {
  const a = int(12,54), b=int(8,100-a);
  const x=int(35,100), y=int(8,x-1);
  const f=int(3,11), g=int(1,10);
  const divisor=int(3,10), quotient=int(1,10);
  const books=int(1,10), boxes=int(3,11);
  const tasks=[
    {label:'Plus-Rechnen',context:'',question:`Wie viel ist ${a} + ${b}?`,answer:String(a+b),options:numericChoices(a+b,10),hint:'Addiere zuerst die Hunderter, dann Zehner und Einer.',explanation:`${a} + ${b} = ${a+b}. Gut gerechnet!`},
    {label:'Minus-Rechnen',context:'',question:`Wie viel ist ${x} − ${y}?`,answer:String(x-y),options:numericChoices(x-y,10),hint:'Du kannst die Zahl in Hunderter, Zehner und Einer zerlegen.',explanation:`${x} − ${y} = ${x-y}. Klasse!`},
    {label:'Einmaleins',context:'',question:`Wie viel ist ${f} × ${g}?`,answer:String(f*g),options:numericChoices(f*g,Math.max(2,f)),hint:`Zähle ${g} Mal die Zahl ${f}.`,explanation:`${f} × ${g} = ${f*g}. Weiter so!`},
    {label:'Geteilt-Rechnen',context:'',question:`Wie viel ist ${divisor*quotient} ÷ ${divisor}?`,answer:String(quotient),options:numericChoices(quotient,1),hint:`Welche Zahl mal ${divisor} ergibt ${divisor*quotient}?`,explanation:`${divisor*quotient} ÷ ${divisor} = ${quotient}. Richtig!`},
    {label:'Knobelgeschichte',context:`In einer Bücherkiste liegen ${boxes} Stapel. In jedem Stapel sind ${books} Bücher.`,question:'Wie viele Bücher sind das insgesamt?',answer:String(books*boxes),options:numericChoices(books*boxes,boxes),hint:`Rechne ${boxes} × ${books}.`,explanation:`${boxes} × ${books} = ${books*boxes} Bücher. Super gelöst!`}
  ];
  return shuffle(tasks);
}

const germanBank = [
 {label:'Lesedetektive',context:'Mira entdeckt am Bach einen kleinen Frosch. Er sitzt auf einem warmen Stein. Als ein Schmetterling vorbeifliegt, springt der Frosch ins Wasser.',question:'Wo saß der Frosch zuerst?',answer:'Auf einem Stein',options:['Auf einem Stein','Unter einem Baum','Auf einer Blume','In einer Höhle'],hint:'Lies den zweiten Satz noch einmal.',explanation:'Im zweiten Satz steht, dass der Frosch auf einem warmen Stein sitzt.'},
 {label:'Lesedetektive',context:'Tariq möchte für seine Oma einen Kuchen backen. Zuerst holt er Mehl und Eier aus der Küche. Dann rührt er den Teig. Am Ende stellt er den Kuchen in den Ofen.',question:'Was macht Tariq direkt vor dem Backen?',answer:'Er rührt den Teig.',options:['Er rührt den Teig.','Er isst ein Stück Kuchen.','Er deckt den Tisch.','Er gießt Blumen.'],hint:'Achte auf das Wort „Dann“ in der Geschichte.',explanation:'Vor dem Ofen rührt Tariq den Teig.'},
 {label:'Wortarten',context:'Nomen bezeichnen zum Beispiel Dinge, Menschen, Tiere oder Gefühle.',question:'Welches Wort ist ein Nomen?',answer:'Abenteuer',options:['Abenteuer','laufen','mutig','schnell'],hint:'Welches Wort kannst du mit „das“ benutzen?',explanation:'„Das Abenteuer“ ist ein Nomen und wird großgeschrieben.'},
 {label:'Wortarten',context:'Verben sagen dir, was jemand tut oder was geschieht.',question:'Welches Wort ist ein Verb?',answer:'springen',options:['springen','der Ball','fröhlich','die Sonne'],hint:'Was kann man tun?',explanation:'„Springen“ bezeichnet eine Tätigkeit und ist ein Verb.'},
 {label:'Wortarten',context:'Adjektive beschreiben, wie etwas ist.',question:'Welches Wort ist ein Adjektiv?',answer:'leuchtend',options:['leuchtend','der Stern','fliegen','der Himmel'],hint:'Wie könnte ein Stern aussehen?',explanation:'„Leuchtend“ beschreibt eine Eigenschaft.'},
 {label:'Satzzeichen',context:'Eine Frage endet mit einem besonderen Zeichen.',question:'Welcher Satz ist richtig geschrieben?',answer:'Wo ist mein Buch?',options:['Wo ist mein Buch?','Wo ist mein Buch.','Wo ist mein Buch!','Wo ist mein Buch,'],hint:'Welches Satzzeichen steht am Ende einer Frage?',explanation:'Eine Frage endet mit einem Fragezeichen.'},
 {label:'Rechtschreibung',context:'Am Satzanfang schreibt man das erste Wort groß.',question:'Welcher Satz ist richtig?',answer:'Heute spielen wir draußen.',options:['Heute spielen wir draußen.','heute spielen wir draußen.','Heute Spielen Wir Draußen.','Heute spielen wir Draußen.'],hint:'Den Satzanfang schreiben wir groß. „draußen“ bleibt klein.',explanation:'„Heute“ ist am Satzanfang groß, die übrigen Wörter stehen hier klein.'},
 {label:'Sinnverstehen',context:'Lina zieht ihre Regenjacke an. Draußen hängen dunkle Wolken am Himmel und der Wind pfeift.',question:'Welches Wetter erwartet Lina vermutlich?',answer:'Regen und Wind',options:['Regen und Wind','Sonnenschein','Schnee und Frost','Große Hitze'],hint:'Denke an die Jacke und die Wolken.',explanation:'Regenjacke, dunkle Wolken und Wind lassen Regen und Wind vermuten.'},
 {label:'Wörter entdecken',context:'Manche Wörter haben eine ähnliche Bedeutung.',question:'Welches Wort bedeutet ungefähr dasselbe wie „fröhlich“?',answer:'glücklich',options:['glücklich','traurig','müde','langsam'],hint:'Wie fühlst du dich, wenn du dich freust?',explanation:'„Fröhlich“ und „glücklich“ haben eine ähnliche Bedeutung.'},
 {label:'Wörter entdecken',context:'Das Gegenteil beschreibt einen starken Unterschied.',question:'Was ist das Gegenteil von „leise“?',answer:'laut',options:['laut','ruhig','sanft','still'],hint:'Denke an einen lauten Trommelschlag.',explanation:'Das Gegenteil von „leise“ ist „laut“.'}
];
function makeGermanTasks() {
  // Jede Mission enthält mindestens zwei kurze Lesetexte.
  const reading = germanBank.filter(q => q.label === 'Lesedetektive');
  const other = shuffle(germanBank.filter(q => q.label !== 'Lesedetektive')).slice(0,3);
  return shuffle([...reading,...other]).map(q => ({...q,options:shuffle(q.options)}));
}
function renderProgress() {
  if(progress.day !== todayLocal()) {progress.day=todayLocal();progress.todayAnswered=0;try{localStorage.setItem(STORAGE_KEY,JSON.stringify(progress));}catch(_) {}}
  element('stars-header').textContent=progress.stars;
  element('goal-label').textContent=`${Math.min(progress.todayAnswered,DAILY_TARGET)} / ${DAILY_TARGET}`;
  element('goal-fill').style.width=`${Math.min(100,progress.todayAnswered/DAILY_TARGET*100)}%`;
  element('stat-stars').textContent=progress.stars;
  element('stat-answered').textContent=progress.answered;
  element('stat-sessions').textContent=progress.sessions;
  const reviewStat=element('stat-reviews');
  if(reviewStat) reviewStat.textContent=progress.reviewBank.length;
  renderSkillProgress();
  renderReviewList();
}
function showView(name) {
  if('speechSynthesis' in window) window.speechSynthesis.cancel();
  if(name!=='times' && typeof timesAbandon==='function') timesAbandon();
  ['home','play','end','progress','memory','times'].forEach(view=>element(`view-${view}`).classList.toggle('hidden',view!==name));
  document.querySelectorAll('.nav-button').forEach(btn=>{
    const active = btn.dataset.view === name || (name === 'play' && session && btn.dataset.view === session.subject);
    btn.classList.toggle('active',active);
    if(active) btn.setAttribute('aria-current','page'); else btn.removeAttribute('aria-current');
  });
  window.scrollTo({top:0,behavior:'instant'});
}
function startSession(subject) {
  const level=progress.skills[subject].level;
  const tasks=subject==='math'
    ? Array.from({length:Math.ceil(MATH_MISSION_TARGET/TASKS_PER_MISSION)},()=>makeSubjectTasks(subject,level)).flat().slice(0,MATH_MISSION_TARGET)
    : makeSubjectTasks(subject,level);
  session = {subject,tasks,index:0,misses:0,earned:0,answeredThisTask:false,hintUsed:false,levelChange:null,
    targetCorrect:tasks.length,correctSolved:0};
  progress.lastSubject=subject;saveProgress();
  showView('play');renderTask();
}
function renderTask() {
  const task=session.tasks[session.index];
  const realSubject=task.subject || session.subject;
  const isMixed=session.mode==='mixed';
  session.misses=0;session.answeredThisTask=false;session.hintUsed=false;
  element('mission-count').textContent=isMixed
    ? `Aufgabe ${session.index+1} von ${MIXED_LENGTH} · ${mixedSolvedCount(session)} geschafft`
    : `${session.correctSolved} von ${session.targetCorrect} richtig · Aufgabe ${session.index+1}`;
  element('mission-fill').style.width=isMixed
    ? `${mixedSolvedCount(session)/MIXED_LENGTH*100}%`
    : `${session.correctSolved/session.targetCorrect*100}%`;
  element('mission-kind').textContent=isMixed
    ? `🎲 LERNMIX · ${SUBJECT_ICONS[realSubject]} ${SUBJECT_NAMES[realSubject].toUpperCase()}`
    : `${SUBJECT_ICONS[session.subject]} ${SUBJECT_NAMES[session.subject].toUpperCase()}-MISSION`;
  element('mission-title').textContent=task.label;
  element('mission-question').textContent=task.question;
  element('mission-context').textContent=task.context;
  element('mission-context').classList.toggle('hidden',!task.context);
  element('current-level').textContent=`Stufe ${progress.skills[realSubject].level} · ${SUBJECT_NAMES[realSubject]}`;
  const mixedNote=element('mixed-note');
  if(mixedNote) {
    mixedNote.classList.toggle('hidden',!isMixed);
    if(isMixed) mixedNote.textContent=`🎯 20 Aufgaben aus 4 Welten · ${session.rewinds} Rücksprünge · Schon richtig gelöste Fragen werden durch neue ersetzt.`;
  }
  element('level-up-notice').classList.add('hidden');
  element('celebration').classList.add('hidden');
  element('read-button').textContent=task.speakText?'🔊 Wort hören':'🔊 Vorlesen';
  const visual=element('question-visual');visual.replaceChildren();
  if(task.visualFlag) {
    const picture=document.createElement('img');picture.src=task.visualFlag;
    picture.alt='Errate das Land dieser Flagge';picture.className='big-flag';visual.append(picture);
  } else if(realSubject!=='english' && task.visualEmoji) {
    // Schutz auch für ältere, lokal gespeicherte Englisch-Wiederholungsfragen.
    const symbol=document.createElement('span');symbol.className='big-emoji';symbol.textContent=task.visualEmoji;visual.append(symbol);
  }
  visual.classList.toggle('hidden',!task.visualFlag && (realSubject==='english'||!task.visualEmoji));
  element('hint-text').textContent=`💡 ${task.hint}`;
  element('hint-text').classList.add('hidden');
  element('answer-feedback').className='feedback hidden';
  element('answer-feedback').textContent='';
  element('next-button').classList.add('hidden');
  const optionContainer=element('answer-options');
  optionContainer.replaceChildren();
  for (const choice of task.options) {
    const btn=document.createElement('button');
    btn.type='button';btn.className='answer-option';
    if(task.optionFlags?.[choice]){
      const picture=document.createElement('img');picture.src=task.optionFlags[choice];
      picture.alt=`Flagge von ${choice}`;picture.className='option-flag';
      const caption=document.createElement('span');caption.textContent=choice;caption.className='sr-only';
      btn.append(picture,caption);btn.setAttribute('aria-label',`Flagge von ${choice}`);
    } else btn.textContent=choice;
    btn.addEventListener('click',()=>selectAnswer(btn,choice));
    optionContainer.appendChild(btn);
  }
}
// Falsch beantwortete Fragen werden nach exakt zwei Sekunden automatisch verlassen.
// Den laufenden Lernmodus und die Frage vor dem Sprung erneut kontrollieren.
function advanceAfterWrong(activeSession,questionIndex) {
  setTimeout(()=>{
    if(session!==activeSession || session.index!==questionIndex ||
       !session.answeredThisTask || element('view-play').classList.contains('hidden'))return;
    advancePlaySession();
  },2000);
}
function showCorrectOption(task) {
  [...element('answer-options').children].forEach((option,index)=>{
    option.disabled=true;
    if(task.options[index]===task.answer)option.classList.add('correct');
  });
}
function advancePlaySession() {
  if(!session || !session.answeredThisTask)return;
  if(session.mode==='mixed') {advanceMixedSession();return;}
  if(session.correctSolved>=session.targetCorrect) {completeSession();return;}
  session.index++;
  if(session.index>=session.tasks.length) {
    // Sicherheitsnetz fuer eine ungewoehnlich kurze oder abgebrochene Aufgabenliste.
    session.tasks.push(...makeSubjectTasks(session.subject,progress.skills[session.subject].level));
  }
  renderTask();
}
function selectAnswer(button,choice) {
  if(!session || session.answeredThisTask) return;
  const task=session.tasks[session.index];
  const feedback=element('answer-feedback');
  feedback.classList.remove('hidden','good','try');
  if(session.mode==='mixed') {
    if(choice===task.answer) {
      mixedCorrectAnswer(button,task,feedback);
      advancePlaySession(); // Unmittelbar zur naechsten Frage / zum Ergebnis.
    } else {
      mixedWrongAnswer(button,task,feedback); // Lernmix-Ruecksprung und Lernkartei bleiben erhalten.
      showCorrectOption(task);
      feedback.textContent=`💡 Richtige Lösung: ${task.answer}. ${task.explanation} · Weiter in 2 Sekunden.`;
      element('next-button').classList.add('hidden');
      advanceAfterWrong(session,session.index);
    }
    return;
  }
  if(choice===task.answer) {
    button.classList.add('correct');
    session.answeredThisTask=true;
    session.correctSolved++;
    const earned=session.misses===0&&!session.hintUsed?2:1;
    session.earned+=earned;
    progress.stars+=earned;progress.answered++;progress.todayAnswered++;
    const change=updateSkill(session.subject,session.misses,session.hintUsed);
    recordLearningSuccess(task,session.subject,session.misses===0&&!session.hintUsed);
    if(change) {
      session.levelChange=change;refreshFutureTasks();
      const notice=element('level-up-notice');
      notice.textContent=change==='up'?'🌟 Super! Neue Lernstufe freigeschaltet!':'💪 Wir üben noch ein bisschen zusammen.';
      notice.classList.remove('hidden');
    }
    element('celebration').classList.remove('hidden');
    saveProgress();
    feedback.classList.add('good');
    feedback.textContent=`🎉 Richtig! ${task.explanation} +${earned} ${earned===1?'Stern':'Sterne'}`;
    for(const option of element('answer-options').children) option.disabled=true;
    element('mission-fill').style.width=`${session.correctSolved/session.targetCorrect*100}%`;
    advancePlaySession(); // Richtige Antwort: ohne Wartezeit / Weiter-Button.
  } else {
    button.classList.add('incorrect');
    session.answeredThisTask=true; // Nicht erneut klicken, bis die Lösung verschwunden ist.
    session.misses++;
    recordLearningMistake(task,session.subject);
    saveProgress();
    // Die falsche Antwort zaehlt nicht zu den Zielaufgaben. Neue Aufgabe anhaengen.
    const replacements=makeSubjectTasks(session.subject,progress.skills[session.subject].level);
    const replacement=replacements.find(item=>item.question!==task.question) || replacements[0];
    session.tasks.push(replacement);
    showCorrectOption(task);
    feedback.classList.add('try');
    feedback.textContent=`💡 Richtige Lösung: ${task.answer}. ${task.explanation} · Weiter in 2 Sekunden.`;
    element('next-button').classList.add('hidden');
    advanceAfterWrong(session,session.index);
  }
}
function completeSession() {
  if(session?.mode==='mixed') {
    progress.sessions++;saveProgress();
    element('end-copy').textContent=`🎲 Du hast alle 20 Aufgaben aus Mathe, Deutsch, Englisch und Flaggen geschafft! ${session.rewinds} Rücksprünge haben dir beim Üben geholfen. ${progress.reviewBank.length} Themen sind noch für spätere Wiederholungen vorgemerkt.`;
    element('end-stars').textContent=`⭐ +${session.earned} Sterne`;
    showView('end');return;
  }
  progress.sessions++;saveProgress();
  element('end-copy').textContent=`Du hast ${session.correctSolved} Aufgaben richtig gelöst! In ${SUBJECT_NAMES[session.subject]} bist du auf Stufe ${progress.skills[session.subject].level}. Auf zur nächsten Entdeckungsreise!`;
  element('end-stars').textContent=`⭐ +${session.earned} Sterne`;
  showView('end');
}
function speakQuestion() {
  if(!('speechSynthesis' in window)) {
    const feedback=element('answer-feedback');feedback.textContent='Die Vorlesefunktion wird von diesem Browser nicht unterstützt.';feedback.className='feedback try';return;
  }
  const task=session.tasks[session.index];
  window.speechSynthesis.cancel();
  const utterance=new SpeechSynthesisUtterance(task.speakText || `${task.context || ''}. ${task.question}`);
  utterance.lang=task.speechLang||'de-DE';utterance.rate=.85;utterance.pitch=1;
  window.speechSynthesis.speak(utterance);
}
function resetProgress() {
  if(window.confirm('Wirklich alle Sterne und Erfolge auf diesem Gerät löschen?')) {
    progress=emptyProgress();
    if(typeof timesClearProgress==='function') timesClearProgress();
    saveProgress();showView('progress');
  }
}

document.querySelectorAll('[data-view]').forEach(btn=>btn.addEventListener('click',()=>{
  if(SUBJECTS.includes(btn.dataset.view)) startSession(btn.dataset.view);
  else if(btn.dataset.view==='memory') startMemoryGame();
  else if(btn.dataset.view==='mixed') beginMixedSession();
  else showView(btn.dataset.view);
}));
element('quick-start').addEventListener('click',()=>startSession(SUBJECTS[(SUBJECTS.indexOf(progress.lastSubject)+1)%SUBJECTS.length]));
element('mixed-start').addEventListener('click',beginMixedSession);
element('back-button').addEventListener('click',()=>showView('home'));
element('hint-button').addEventListener('click',()=>{
  if(session && !session.answeredThisTask) {
    session.hintUsed=true;
    if(session.mode==='mixed') session.hadHint[session.index]=true;
  }
  element('hint-text').classList.remove('hidden');
});
element('read-button').addEventListener('click',speakQuestion);
// Nur technische Rueckfall-Option: im normalen Lernfluss wird automatisch weitergeschaltet.
element('next-button').addEventListener('click',advancePlaySession);
element('repeat-button').addEventListener('click',()=>session?.mode==='mixed'?beginMixedSession():startSession(session.subject));
element('home-button').addEventListener('click',()=>showView('home'));
element('reset-progress').addEventListener('click',resetProgress);
element('memory-back').addEventListener('click',()=>showView('home'));
element('memory-next').addEventListener('click',startMemoryGame);
renderProgress();showView('home');
if('serviceWorker' in navigator && (location.protocol==='https:' || location.hostname==='localhost' || location.hostname==='127.0.0.1')) {
  window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
}
